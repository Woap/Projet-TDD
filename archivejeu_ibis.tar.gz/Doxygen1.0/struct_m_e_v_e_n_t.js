var struct_m_e_v_e_n_t =
[
    [ "bstate", "struct_m_e_v_e_n_t.html#a9a41838a4d21ee4ac414edd7bb4ed713", null ],
    [ "id", "struct_m_e_v_e_n_t.html#afc3e389b26a8fb3c1e864175ddd630fd", null ],
    [ "x", "struct_m_e_v_e_n_t.html#a6150e0515f7202e2fb518f7206ed97dc", null ],
    [ "y", "struct_m_e_v_e_n_t.html#a0a2f84ed7838f07779ae24c5a9086d33", null ],
    [ "z", "struct_m_e_v_e_n_t.html#a14f94e529dff0b8bfba8e16fbe9755d6", null ]
];