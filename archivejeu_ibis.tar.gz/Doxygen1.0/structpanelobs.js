var structpanelobs =
[
    [ "above", "structpanelobs.html#aaec17ed213334e4b5adc6d5b6f817ecb", null ],
    [ "pan", "structpanelobs.html#aa9df4ee5359f2b6cbb0239f80aa32afc", null ]
];