var searchData=
[
  ['key_5fcode',['key_code',['../struct_s_c_r_e_e_n.html#aecbeda191369bce6449240ca59c068c8',1,'SCREEN']]]
];
