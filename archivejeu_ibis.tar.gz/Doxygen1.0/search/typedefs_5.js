var searchData=
[
  ['window',['WINDOW',['../curses_8h.html#a9752d241435873df2ed545d2df9e285b',1,'curses.h']]]
];
