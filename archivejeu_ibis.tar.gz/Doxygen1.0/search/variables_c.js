var searchData=
[
  ['obscure',['obscure',['../structpanel.html#ac8c5bd6051077b20fac46ba549f0f116',1,'panel']]],
  ['orig_5fattr',['orig_attr',['../struct_s_c_r_e_e_n.html#ac0acef6ec187e227d4c16996f7bac8fb',1,'SCREEN']]],
  ['orig_5fback',['orig_back',['../struct_s_c_r_e_e_n.html#a0189c668c7b8a8de411d6ef89d3c7961',1,'SCREEN']]],
  ['orig_5fcursor',['orig_cursor',['../struct_s_c_r_e_e_n.html#a81f845db210da404b00436575e1222bc',1,'SCREEN']]],
  ['orig_5ffore',['orig_fore',['../struct_s_c_r_e_e_n.html#ae2e4988a0318beb11f9fd427ec4ecce0',1,'SCREEN']]]
];
