var searchData=
[
  ['user',['user',['../structpanel.html#a96e9f71ced37cb1a6cafb45fa9a199b5',1,'panel']]]
];
