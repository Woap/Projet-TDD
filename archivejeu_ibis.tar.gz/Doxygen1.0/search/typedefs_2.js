var searchData=
[
  ['chtype',['chtype',['../curses_8h.html#ac2eb9fdcc62d2443bae51d473a073624',1,'curses.h']]]
];
