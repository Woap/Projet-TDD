var searchData=
[
  ['wendx',['wendx',['../structpanel.html#aaddd55b344806f5b07b69b500d7993c9',1,'panel']]],
  ['wendy',['wendy',['../structpanel.html#a5dfa0d08ce959c355613c41c8794f8ea',1,'panel']]],
  ['win',['win',['../structpanel.html#a09d962b38c0d24e36078d717d2a6ed96',1,'panel']]],
  ['wstartx',['wstartx',['../structpanel.html#ae71dc66b796c51066667361aec59af04',1,'panel']]],
  ['wstarty',['wstarty',['../structpanel.html#a9c6e1df3036a5c01cfb2196fa49940d9',1,'panel']]]
];
