var searchData=
[
  ['bool',['bool',['../curses_8h.html#a97a80ca1602ebf2303258971a2c938e2',1,'curses.h']]]
];
