var searchData=
[
  ['obscure',['obscure',['../structpanel.html#ac8c5bd6051077b20fac46ba549f0f116',1,'panel']]],
  ['ok',['OK',['../curses_8h.html#aba51915c87d64af47fb1cc59348961c9',1,'curses.h']]],
  ['orig_5fattr',['orig_attr',['../struct_s_c_r_e_e_n.html#ac0acef6ec187e227d4c16996f7bac8fb',1,'SCREEN']]],
  ['orig_5fback',['orig_back',['../struct_s_c_r_e_e_n.html#a0189c668c7b8a8de411d6ef89d3c7961',1,'SCREEN']]],
  ['orig_5fcursor',['orig_cursor',['../struct_s_c_r_e_e_n.html#a81f845db210da404b00436575e1222bc',1,'SCREEN']]],
  ['orig_5ffore',['orig_fore',['../struct_s_c_r_e_e_n.html#ae2e4988a0318beb11f9fd427ec4ecce0',1,'SCREEN']]],
  ['overlay',['overlay',['../curses_8h.html#a5a2d54f2ce56ba4655019cd318719656',1,'curses.h']]],
  ['overwrite',['overwrite',['../curses_8h.html#a025dc1cfa4aaa8cbd7f5865153d2d9aa',1,'curses.h']]]
];
