var searchData=
[
  ['keyname',['keyname',['../curses_8h.html#a0b4cfa278031f6981d822610f2213882',1,'curses.h']]],
  ['keypad',['keypad',['../curses_8h.html#a603679c31b57c32d57e5e00fe9e5eafc',1,'curses.h']]],
  ['killchar',['killchar',['../curses_8h.html#ae9f174e5c32b5b5e1c86a3897c32ae0f',1,'curses.h']]]
];
