var searchData=
[
  ['true',['TRUE',['../curses_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'curses.h']]]
];
