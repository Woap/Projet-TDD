var searchData=
[
  ['pan',['pan',['../structpanelobs.html#aa9df4ee5359f2b6cbb0239f80aa32afc',1,'panelobs']]],
  ['posx',['posx',['../structjoueur.html#a785822f45512100cdbcc3cfc3da1071f',1,'joueur']]],
  ['posy',['posy',['../structjoueur.html#a613547e48cc748be8044231439c51b29',1,'joueur']]]
];
