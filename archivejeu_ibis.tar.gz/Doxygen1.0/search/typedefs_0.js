var searchData=
[
  ['attr_5ft',['attr_t',['../curses_8h.html#a2051c09d79e0b70be2574e77480236ae',1,'curses.h']]]
];
