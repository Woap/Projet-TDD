var searchData=
[
  ['curses_2eh',['curses.h',['../curses_8h.html',1,'']]]
];
