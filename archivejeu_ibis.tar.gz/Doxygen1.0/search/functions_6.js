var searchData=
[
  ['getattrs',['getattrs',['../curses_8h.html#a17ab272aa6ed226221959bce49540a6f',1,'curses.h']]],
  ['getbegx',['getbegx',['../curses_8h.html#a2cbf68722a05bb47fcc1d1ffe3727cc4',1,'curses.h']]],
  ['getbegy',['getbegy',['../curses_8h.html#acf657ad84cb417f238a9772c2c6e3212',1,'curses.h']]],
  ['getbkgd',['getbkgd',['../curses_8h.html#aac7d444aeb8b2935be11583ae81ccd5f',1,'curses.h']]],
  ['getbmap',['getbmap',['../curses_8h.html#ad31fb7c0328ef79793bc6e84da4d4be5',1,'curses.h']]],
  ['getcurx',['getcurx',['../curses_8h.html#a92465a49debc654a80281fdfb410ec45',1,'curses.h']]],
  ['getcury',['getcury',['../curses_8h.html#af672b5f1b33ea4ffc92f7716131b1db6',1,'curses.h']]],
  ['getmaxx',['getmaxx',['../curses_8h.html#a6d0e4f814de6a09f12351d67c3c1fd59',1,'curses.h']]],
  ['getmaxy',['getmaxy',['../curses_8h.html#aa92d68a7d2db87b3c28fd1bae9d1b4bd',1,'curses.h']]],
  ['getmouse',['getmouse',['../curses_8h.html#a6dc96bda64ef887cd54f8efef07e7446',1,'curses.h']]],
  ['getnstr',['getnstr',['../curses_8h.html#ab3be779adc8fea84680a91d5714fba24',1,'curses.h']]],
  ['getparx',['getparx',['../curses_8h.html#a8147a03f93be02060d381e7befbc509b',1,'curses.h']]],
  ['getpary',['getpary',['../curses_8h.html#a11b473eb3118d1d8700946d76ff1939b',1,'curses.h']]],
  ['getstr',['getstr',['../curses_8h.html#a0ff7fb0b7b0ee62a2b3e280c0551e576',1,'curses.h']]],
  ['getwin',['getwin',['../curses_8h.html#a2bceb1eb95a7732501c98cb5f71d24bc',1,'curses.h']]]
];
