var searchData=
[
  ['qiflush',['qiflush',['../curses_8h.html#aa9fa79f8055d8c179c616ffaa233664d',1,'curses.h']]]
];
