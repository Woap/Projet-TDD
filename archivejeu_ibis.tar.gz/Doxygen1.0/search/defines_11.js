var searchData=
[
  ['xopen',['XOPEN',['../curses_8h.html#aca1c58f85f75a4a04c1b7a6a5da7aec2',1,'curses.h']]]
];
