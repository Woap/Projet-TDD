var searchData=
[
  ['ungetch',['ungetch',['../curses_8h.html#a1de9eb8e6fed0db408f03e3b5a1315da',1,'curses.h']]]
];
