var searchData=
[
  ['save_5fkey_5fmodifiers',['save_key_modifiers',['../struct_s_c_r_e_e_n.html#ad85e445be853c2366872ef720c7b42df',1,'SCREEN']]],
  ['slk_5fwinptr',['slk_winptr',['../struct_s_c_r_e_e_n.html#a7b7e67406852c770f03e6237af449e84',1,'SCREEN']]],
  ['slklines',['slklines',['../struct_s_c_r_e_e_n.html#ac5020faf14784f05bdfe206572f03e5b',1,'SCREEN']]],
  ['sp',['SP',['../curses_8h.html#ae414bb21deea4a88294526bb451fee6d',1,'curses.h']]],
  ['stdscr',['stdscr',['../curses_8h.html#a22d3102a66a6502cad0a170c27e703a3',1,'curses.h']]]
];
