var searchData=
[
  ['panel',['PANEL',['../panel_8h.html#ad3df4725421ec41359505ae2fd0b273d',1,'panel.h']]],
  ['panelobs',['PANELOBS',['../panel_8h.html#a6a6c4828bee1a31d225915d7fc02941e',1,'panel.h']]]
];
