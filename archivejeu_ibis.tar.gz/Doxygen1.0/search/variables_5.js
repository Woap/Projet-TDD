var searchData=
[
  ['echo',['echo',['../struct_s_c_r_e_e_n.html#a38c2832fe7bc03527479255bfc0afe62',1,'SCREEN']]]
];
