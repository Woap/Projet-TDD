var searchData=
[
  ['ok',['OK',['../curses_8h.html#aba51915c87d64af47fb1cc59348961c9',1,'curses.h']]]
];
