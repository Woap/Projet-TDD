var searchData=
[
  ['getbegyx',['getbegyx',['../curses_8h.html#a929ad66ed972039938b365a449f2fb7a',1,'curses.h']]],
  ['getch',['getch',['../curses_8h.html#af06d804ba4b13a2086f028475c0786f4',1,'curses.h']]],
  ['getmaxyx',['getmaxyx',['../curses_8h.html#a900b8af6f5fefb35e238b1b723b3898b',1,'curses.h']]],
  ['getparyx',['getparyx',['../curses_8h.html#a2005e0c6fc485519900402bad0dfd1e2',1,'curses.h']]],
  ['getsyx',['getsyx',['../curses_8h.html#a960598863167b8d89f3d20e26aaceafa',1,'curses.h']]],
  ['getyx',['getyx',['../curses_8h.html#a4a2853a0e3b9684df52598fb3aac6c0e',1,'curses.h']]]
];
