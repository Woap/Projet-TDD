var structpanel =
[
    [ "above", "structpanel.html#a3727675fc9b3ae6cc8f8f9fdc4bb6802", null ],
    [ "below", "structpanel.html#a7b3ce3a97cd3976be0909ea9c107fb77", null ],
    [ "obscure", "structpanel.html#ac8c5bd6051077b20fac46ba549f0f116", null ],
    [ "user", "structpanel.html#a96e9f71ced37cb1a6cafb45fa9a199b5", null ],
    [ "wendx", "structpanel.html#aaddd55b344806f5b07b69b500d7993c9", null ],
    [ "wendy", "structpanel.html#a5dfa0d08ce959c355613c41c8794f8ea", null ],
    [ "win", "structpanel.html#a09d962b38c0d24e36078d717d2a6ed96", null ],
    [ "wstartx", "structpanel.html#ae71dc66b796c51066667361aec59af04", null ],
    [ "wstarty", "structpanel.html#a9c6e1df3036a5c01cfb2196fa49940d9", null ]
];