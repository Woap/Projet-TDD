var struct_m_o_u_s_e___s_t_a_t_u_s =
[
    [ "button", "struct_m_o_u_s_e___s_t_a_t_u_s.html#aa89fba3c417cf57fbab92bed48ef48c9", null ],
    [ "changes", "struct_m_o_u_s_e___s_t_a_t_u_s.html#a428798c15a127930411bd3af43e3cdc7", null ],
    [ "x", "struct_m_o_u_s_e___s_t_a_t_u_s.html#a6150e0515f7202e2fb518f7206ed97dc", null ],
    [ "y", "struct_m_o_u_s_e___s_t_a_t_u_s.html#a0a2f84ed7838f07779ae24c5a9086d33", null ]
];