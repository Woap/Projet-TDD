var structjoueur =
[
    [ "att", "structjoueur.html#a011a08f01e1a1dc1a7c25c607055e69b", null ],
    [ "def", "structjoueur.html#a1d879277a80820e8232bceb4458507dc", null ],
    [ "posx", "structjoueur.html#a785822f45512100cdbcc3cfc3da1071f", null ],
    [ "posy", "structjoueur.html#a613547e48cc748be8044231439c51b29", null ],
    [ "tab", "structjoueur.html#a51c67bce53f4b850d49b7507ce9a358b", null ],
    [ "vie", "structjoueur.html#a0bfaa2753f83b4e0d815541c60a20d5b", null ]
];