var annotated =
[
    [ "_win", "struct__win.html", "struct__win" ],
    [ "grille", "structgrille.html", "structgrille" ],
    [ "joueur", "structjoueur.html", "structjoueur" ],
    [ "MEVENT", "struct_m_e_v_e_n_t.html", "struct_m_e_v_e_n_t" ],
    [ "MOUSE_STATUS", "struct_m_o_u_s_e___s_t_a_t_u_s.html", "struct_m_o_u_s_e___s_t_a_t_u_s" ],
    [ "panel", "structpanel.html", "structpanel" ],
    [ "panelobs", "structpanelobs.html", "structpanelobs" ],
    [ "SCREEN", "struct_s_c_r_e_e_n.html", "struct_s_c_r_e_e_n" ]
];