var annotated =
[
    [ "grille", "structgrille.html", "structgrille" ],
    [ "joueur", "structjoueur.html", "structjoueur" ],
    [ "mob", "structmob.html", "structmob" ]
];