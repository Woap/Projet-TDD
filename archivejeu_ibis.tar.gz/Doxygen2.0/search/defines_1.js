var searchData=
[
  ['img_5fgeterror',['IMG_GetError',['../_s_d_l__image_8h.html#aa26bff3cc4fbcfd9dcc1756d1a398ba1',1,'SDL_image.h']]],
  ['img_5fseterror',['IMG_SetError',['../_s_d_l__image_8h.html#a4f62490add1442e80bffdc07c959f10f',1,'SDL_image.h']]]
];
