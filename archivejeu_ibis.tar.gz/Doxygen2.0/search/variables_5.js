var searchData=
[
  ['posx',['posx',['../structjoueur.html#a785822f45512100cdbcc3cfc3da1071f',1,'joueur::posx()'],['../structmob.html#a785822f45512100cdbcc3cfc3da1071f',1,'mob::posx()']]],
  ['posy',['posy',['../structjoueur.html#a613547e48cc748be8044231439c51b29',1,'joueur::posy()'],['../structmob.html#a613547e48cc748be8044231439c51b29',1,'mob::posy()']]]
];
