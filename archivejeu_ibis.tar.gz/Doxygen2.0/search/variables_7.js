var searchData=
[
  ['vie',['vie',['../structjoueur.html#a0bfaa2753f83b4e0d815541c60a20d5b',1,'joueur::vie()'],['../structmob.html#a0bfaa2753f83b4e0d815541c60a20d5b',1,'mob::vie()']]]
];
