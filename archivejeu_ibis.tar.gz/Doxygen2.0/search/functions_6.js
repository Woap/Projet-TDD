var searchData=
[
  ['new_5fgrille',['new_grille',['../fonction__grille_8h.html#a7b2a5d5e22122bc32b9ec570d066d2d1',1,'new_grille(grille *x, int n, int m):&#160;fonction_grille.c'],['../fonction__grille_8c.html#a7b2a5d5e22122bc32b9ec570d066d2d1',1,'new_grille(grille *x, int n, int m):&#160;fonction_grille.c']]]
];
