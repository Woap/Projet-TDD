var searchData=
[
  ['pause',['pause',['../fonction__jeu_8h.html#a7167f5c196fc5e167bfabde1a730e81d',1,'pause():&#160;fonction_jeu.h'],['../fonction__jeu_8c.html#af5b50711f9db85e482924ffaad7d15ea',1,'pause(SDL_Surface *screen, joueur *j):&#160;fonction_jeu.c']]],
  ['posx',['posx',['../structjoueur.html#a785822f45512100cdbcc3cfc3da1071f',1,'joueur::posx()'],['../structmob.html#a785822f45512100cdbcc3cfc3da1071f',1,'mob::posx()']]],
  ['posy',['posy',['../structjoueur.html#a613547e48cc748be8044231439c51b29',1,'joueur::posy()'],['../structmob.html#a613547e48cc748be8044231439c51b29',1,'mob::posy()']]]
];
