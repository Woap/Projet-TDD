/**
* @file jeu.h
* @brief fonctionnalit� du jeu
* @author ibis ibrahim
* @date 11/04/2015
*/

#ifndef __JEU_H_
#define __JEU_H_


typedef struct {
    int posx ;
    int posy ;
    int vie ;
    int att ;
    int def ;
    char tab[10] ;
} joueur ;

typedef struct
{
    int ** grille ;
    int n ;
    int m ;
} grille ;

/**
* @brief cr�er une nouvelle grille
* @param (int n) -> ligne de la grille / (int m) -> colonne de la grille
* @return retourne une grille de taille n*m
*/
grille new_grille( int n, int m);

/**
* @brief initialise une grille
* @param grille x -> une grille quelconque
* @return retourne une grille initialis� � 0
*/
void init_grille(grille x);

/**
* @brief affichage d'une grille
* @param grille x -> une grille quelconque
*/
void affiche_grille(grille x,joueur q);

/**
* @brief lecture fichier texte
* @param grille *x -> adresse d'une grille quelconque / joueur *p -> adresse d'un joueur
*/
void lecture_grille(grille *x, joueur *p);

/**
* @brief deplacement du joueur
* @param  grille *x -> adresse d'une grille quelconque / joueur *j -> adresse d'un joueur
*/
void deplacer_joueur(grille *x, joueur *j);

/**
* @brief initialisation des points du joueur
* @param  joueur *p -> adresse d'un joueur
*/
void init_joueur( joueur *p);

/**
* @brief lib�re la grille
* @param grille x -> une grille quelconque
*/
void free_grille(grille x);

#endif
