#include <stdio.h>
#include <stdlib.h>
#include "grille.h"
#include "jeu.h"

grille new_grille( int n, int m)
{
    int i;
    grille nouv;
    nouv.n=n;
    nouv.m=m;
    nouv.grille=(grille **) malloc ((n)*sizeof(grille*));
    for ( i=0 ; i < n ; i++ )
        nouv.grille[i]=(grille*) malloc ((m)*sizeof(grille));

    return nouv;

}

void init_grille(grille x)
{
    int i,j;
    for ( i=0 ; i < (x.n) ; i++ )
    {
        for ( j=0 ; j < (x.m) ; j++ )
        {
            x.grille[i][j]=0;
        }
    }

}

void affiche_grille(grille x,joueur q)
{
    int i,j,s=0;
    x.grille[q.posx][q.posy]=9;
    printf("VIE: %d\n",q.vie);
    printf("ATT: %d | DEF : %d \n",q.att,q.def);
    printf("\n");
    printf(" ");
    for ( i= 0 ; i < x.n ; i++)
        printf("-");
    printf("\n");

    for ( i = 0 ; i < (x.n) ; i++ )
    {
        printf("|");
        for ( j = 0 ; j < (x.m) ; j++ )
        {
            printf("%d",x.grille[i][j]);

        }
        printf("|\n");
    }
    printf(" ");
    for ( i= 0 ; i < x.n ; i++)
        printf("-");

    while(s<8)
    {
        printf("\n");
        s++;
    }
}


grille lecture_grille()
{
    int n,m;
    FILE *fd;
    int lecture = 0;
    joueur p;
    char temp[1];
    int i,j;
    int nombre=0;

    fd= fopen("grille1.txt","r");

    if ( fd == NULL )
    {
        perror("Erreur ouverture grille");
        exit (1);
    }

    fscanf(fd,"%d %d",&n,&m); // taille de la grille
    grille x=new_grille(n,m);
    init_grille(x);



    fscanf(fd,"%d %d ",&p.posx,&p.posy); // position du joueur

    printf("Position du joueur : %d %d\n",p.posx,p.posy);
    for ( i=0 ; i < n ; i ++)
    {
        for ( j=0 ; j < m ; j++)
        {

            lecture = fgetc(fd);
            fgetc(fd);
            sprintf(temp,"%c",lecture);
            nombre= atoi(temp);

            printf("%d ",nombre); // je v�rifie les valeurs qui ont �t� lus
            x.grille[i][j] = nombre;
        }

    }


    return x;
}
