#include <stdio.h>
#include <stdlib.h>
#include "jeu.h"
#include <ncurses.h>

grille new_grille( int n, int m)
{
    int i;
    grille nouv;
    nouv.n=n;
    nouv.m=m;
    nouv.grille=(grille **) malloc ((n)*sizeof(grille*));
    for ( i=0 ; i < n ; i++ )
        nouv.grille[i]=(grille*) malloc ((m)*sizeof(grille));

    return nouv;

}

void init_grille(grille x)
{
    int i,j;
    for ( i=0 ; i < (x.n) ; i++ )
    {
        for ( j=0 ; j < (x.m) ; j++ )
        {
            x.grille[i][j]=0;
        }
    }

}

void affiche_grille(grille x,joueur q)
{
    int i,j,s=0;
    x.grille[q.posx][q.posy]=9;
    printf("VIE: %d\n",q.vie);
    printf("ATT: %d | DEF : %d \n",q.att,q.def);
    printf("\n");
    printf(" ");
    for ( i= 0 ; i < x.n ; i++)
        printf("-");
    printf("\n");

    for ( i = 0 ; i < (x.n) ; i++ )
    {
        printf("|");
        for ( j = 0 ; j < (x.m) ; j++ )
        {
            printf("%d",x.grille[i][j]);

        }
        printf("|\n");
    }
    printf(" ");
    for ( i= 0 ; i < x.n ; i++)
        printf("-");

    while(s<8)
    {
        printf("\n");
        s++;
    }
}

void affiche_grille2(grille x,joueur q)
{
    int i,j,s=0;
    x.grille[q.posx][q.posy]=9;
    mvprintw(0,0,"VIE: %d",q.vie);
    mvprintw(1,0,"ATT: %d | DEF : %d ",q.att,q.def);

    for ( i= 0 ; i < x.n ; i++)
        mvprintw(2,i+1,"-");


    for ( i = 0 ; i < (x.n) ; i++ )
    {
        mvprintw(i+3,0,"|");
        for ( j = 0 ; j < (x.m) ; j++ )
        {
            mvprintw(i+3,j+1,"%d",x.grille[i][j]);

        }
        mvprintw(i+3,x.n+1,"|");
    }

    for ( i= 0 ; i < x.n ; i++)
        mvprintw(x.m+3,i+1,"-");
    refresh();


}


void lecture_grille(grille *x,joueur *p)
{
    int n,m;
    FILE *fd;
    int lecture = 0;
    char temp[1];
    int i,j;
    int nombre=0;

    fd= fopen("grille1.txt","r");

    if ( fd == NULL )
    {
        perror("Erreur ouverture grille");
        exit (1);
    }

    fscanf(fd,"%d %d",&n,&m); // taille de la grille
    *x=new_grille(n,m);
    init_grille(*x);

    fscanf(fd,"%d %d ",&(p->posx),&(p->posy)); // position du joueur

    for ( i=0 ; i < x->n ; i ++)
    {
        for ( j=0 ; j < x->m ; j++)
        {

            lecture = fgetc(fd);
            fgetc(fd);
            sprintf(temp,"%c",lecture);
            nombre= atoi(temp);
            x->grille[i][j] = nombre;
        }

    }
}


void deplacer_joueur(grille *x, joueur *j)
{
    int key;
    key=0;
    key = getch() ;
    /*if ( key == 224)
    {
        key = getch(); // WINDOWS
    }*/

    switch(key)
    {
    case 75: //GAUCHE
        if (j->posy-1 < 0)
            break;
        if (x->grille[j->posx][j->posy-1] == 1 )
            break;
        if (x->grille[j->posx][j->posy-1] == 2 )
            j->vie--;

        x->grille[j->posx][j->posy]=0;
        j->posy--;

        break;

    case 77: //DROITE
        if (j->posy+1 > x->n-1)
            break;
        if (x->grille[j->posx][j->posy+1] == 1 )
            break;
        if (x->grille[j->posx][j->posy+1] == 2 )
            j->vie--;

        x->grille[j->posx][j->posy]=0;
        j->posy++;
        break;
    case 80: // BAS
        if (j->posx+1 > x->m-1)
            break;
        if (x->grille[j->posx+1][j->posy] == 1 )
            break;
        if (x->grille[j->posx+1][j->posy] == 2 )
            j->vie--;

        x->grille[j->posx][j->posy]=0;
        j->posx++;
        break;
    case 72: //HAUT
        if (j->posx-1 < 0)
            break;
        if (x->grille[j->posx-1][j->posy] == 1 )
            break;
        if (x->grille[j->posx-1][j->posy] == 2 )
            j->vie--;

        x->grille[j->posx][j->posy]=0;
        j->posx--;
        break;
    }
}

void init_joueur( joueur *p)
{
    p->att=1;
    p->def=1;
    p->vie=5;
}

void free_grille(grille x)
{
    int i;
    for ( i = 0 ; i < (x.n) ; i ++ )
    {
        free(x.grille[i]);
        x.grille[i]= NULL;
    }

    free(x.grille);
    x.grille= NULL;
}

