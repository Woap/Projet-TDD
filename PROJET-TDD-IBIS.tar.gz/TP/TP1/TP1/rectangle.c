#include <stdio.h>
#include <stdlib.h>
#include "rectangle.h"
#include "cercle.h"
#include "point.h"

rectangle rectangle_encadrant( cercle c1, cercle c2)
{
    float xmin = xmin(cercle c1, cercle c2);
    float ymin = ymin(cercle c1, cercle c2);
    float xmax = xmax(cercle c1, cercle c2);
    float ymax = ymax(cercle c1, cercle c2);

    point xmin_ymin;
    point xmax_ymax;

    xmin_ymin.x=xmin;
    xmin_ymin.y=ymin;
    xmax_ymax.x=xmax;
    xmax_ymax.y=ymax;

    rectangle r;
    r.xmin_ymin=xmin_ymin;
    r.xmax_ymax=xmax_ymax;

    return r;
}

float surface_rectangle(rectangle r);
{
    float longueur = distance ( r.xmin_ymin

