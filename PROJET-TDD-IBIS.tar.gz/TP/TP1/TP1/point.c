#include <stdio.h>
#include <stdlib.h>
#include "point.h"
#include "rectangle.h"
#include <math.h>

point point_aleatoire(rectangle r);
{



}

float distance ( point pt1 , point pt2 )
{
    double d  = sqrt(pow((pt2.x - pt1.x ), 2) + (pow(pt2.y - pt1.y),2));

    return d;
}
