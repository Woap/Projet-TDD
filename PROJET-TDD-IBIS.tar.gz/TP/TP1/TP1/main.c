#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "main.h"
#include "cercle.h"
#include "rectangle.h

int main()
{
    int n=0
    cercle c1;
    cercle c2;
    rectangle r = rectangle_encadrant ( c1,c2 );
    int nbr_point_intersection = 0;
    printf("Nbr tirage point aléatoire ? \n");
    scanf(" %d",n);

    srand( time(NULL) );




    for ( i = 0 ; i < n ; i ++ )
    {
        point pt_aleat = point_aleatoire(r);
        if ( appartient(pt_aleat, c1) && appartient(pt_aleat,c2) )
        {
            nbr_point_intersection++;
        }
    }

    proportion_point_intersection = nbr_point_intersection / n;
    surface_intersection = proportion_point_intersection * surface_rectangle(r);
}
