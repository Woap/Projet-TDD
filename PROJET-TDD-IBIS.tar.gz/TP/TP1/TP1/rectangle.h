#ifndef __RECTANGLE_H_
#define __RECTANGLE_H_

typedef struc { point xmin_ymin; point xmax_ymax; ) rectangle;
rectangle rectangle_encadrant(cercle c1, cercle c2);
float surface_rectangle(rectangle r);

#endif
