


rectangle rectangle_encadrant(cercle, cercle);
float surface_rectangle (rectangle );
