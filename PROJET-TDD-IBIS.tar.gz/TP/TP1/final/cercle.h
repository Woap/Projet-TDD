
float xmin(cercle , cercle);
float ymin(cercle , cercle );
float xmax(cercle , cercle );
float ymax(cercle , cercle );
