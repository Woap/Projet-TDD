#include <stdio.h>
#include <stdlib.h>
#include "point.h"

point point_aleatoire(rectangle r)
{
    point aleat;
    aleat.x =( rand()/(double)RAND_MAX ) * (r.xmax_ymax.x-r.xmin_ymin.x) + r.xmin_ymin.x;
    aleat.y =( rand()/(double)RAND_MAX ) * (r.xmax_ymax.y-r.xmin_ymin.y) + r.xmin_ymin.y;
    return aleat;

}

int appartient( point pt, cercle c )
{
    if ((distance(pt, c.centre)) <= c.rayon)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
