typedef struct { float x ; float y ; } point ;

point point_aleatoire(rectangle);


