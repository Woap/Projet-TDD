#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "cercle.h"
#include "rectangle.h"
#include "point.h"

int main()
{
    int n=0;
    int i ;
    cercle c1;
    cercle c2;
    srand( time(NULL) );


    float x,y;
    printf("Rayon du cercle 1 :"); scanf(" %f",c1.rayon);
    printf("Coordonnes Centre du cercle 1 : \n");
    printf("x="); scanf("%f",&x);
    printf("y="); scanf("%f",&y);
    point s;
    s.x=x;
    s.y=y;
    c1.centre=s;

    float a,b;
    printf("Rayon du cercle 2 :"); scanf(" %f",c2.rayon);
    printf("Coordonnes Centre du cercle 2 : \n ");
    printf("x="); scanf("%f",&a);
    printf("y="); scanf("%f",&b);
    point d;
    d.x=a;
    d.y=b;
    c1.centre=d;


    rectangle r;
    r=rectangle_encadrant (c1,c2);

    int nbr_point_intersection = 0;
    printf("Nbr tirage point al�atoire ? \n");
    scanf(" %d",&n);


    for ( i = 0 ; i < n ; i ++ )
    {
        point pt_aleat = point_aleatoire(r);
        if ( appartient(pt_aleat, c1) + appartient(pt_aleat,c2) == 2 )
        {
            nbr_point_intersection++;
        }
    }

    float proportion_point_intersection = nbr_point_intersection / n;
    float surface_intersection = proportion_point_intersection * surface_rectangle(r);

    printf("La surface est de : %f",surface_intersection);
    return 0;




}
