#include <stdio.h>
#include <stdlib.h>
#include "cercle.h"


float xmin(cercle c1,cercle c2)
{
    if ( (c1.centre.x - c1.rayon) < (c2.centre.x - c2.rayon) )
    {
        return (c1.centre.x - c1.rayon);
    }
    else
    {
        return (c2.centre.x - c2.rayon);
    }
}

float ymin(cercle c1,cercle c2)
{
    if ( (c1.centre.y - c1.rayon) < (c2.centre.y - c2.rayon) )
    {
        return (c1.centre.y - c1.rayon);
    }
    else
    {
        return (c2.centre.y- c2.rayon);
    }
}

float xmax(cercle c1,cercle c2)
{
    if ( (c1.centre.x + c1.rayon) < (c2.centre.x + c2.rayon) )
    {
        return (c2.centre.x + c2.rayon);
    }
    else
    {
        return (c1.centre.x + c1.rayon);
    }
}

float ymax(cercle c1,cercle c2)
{
    if ( (c1.centre.y + c1.rayon) < (c2.centre.y + c1.rayon ))
    {
        return (c2.centre.y + c2.rayon);
    }
    else
    {
        return (c1.centre.y + c1.rayon);
    }
}








