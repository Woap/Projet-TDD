

#ifndef __RECTANGLE_H_
#define __RECTANGLE_H_


#include "point.h"
#include "cercle.h"


typedef struct { point xmin_ymin; point xmax_ymax; } rectangle;

rectangle rectangle_encadrant(cercle, cercle);
float surface_rectangle (rectangle );

#endif // __RECTANGLE_H_
