

#ifndef __CERCLE_H_
#define __CERCLE_H_



#include "point.h"


typedef struct { point centre ; float rayon;  } cercle;
float xmin(cercle c1, cercle c2);
float ymin(cercle c1, cercle c2);
float xmax(cercle c1, cercle c2);
float ymax(cercle c1, cercle c2);

#endif // __CERCLE_H_
