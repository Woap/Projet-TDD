#include <stdio.h>
#include <stdlib.h>
#include "rectangle.h"





rectangle rectangle_encadrant( cercle c1, cercle c2)
{
    float amin = xmin(c1,c2);
    float bmin = ymin(c1,c2);
    float amax = xmax(c1,c2);
    float bmax = ymax(c1,c2);

    point q;
    point s;

    q.x=amin;
    q.y=bmin;
    s.x=amax;
    s.y=bmax;

    rectangle r;
    r.xmin_ymin=q;
    r.xmax_ymax=s;

    return r;
}

float surface_rectangle (rectangle r)
{
    float hauteur = distance ( r.xmin_ymin.x,r.xmax_ymax.y );
    float longueur = distance ( r.xmin_ymin.x,r.xmax_ymax.x );


    float surface = hauteur * longueur ;

    return surface;
}

