

#ifndef __POINT_H_
#define __POINT_H_

typedef struct { float x ; float y ; } point ;

#include "rectangle.h"
#include "cercle.h"

int appartient(point,cercle );

point point_aleatoire(rectangle);


#endif // __POINT_H_

