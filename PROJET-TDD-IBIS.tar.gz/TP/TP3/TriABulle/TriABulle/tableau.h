
#ifndef __TABLEAU_H_
#define __TABLEAU_H_

typedef struct {
	int* valeurs ;
	int taille ;
} tableau ;

#endif
