#include <stdio.h>
#include "tableau.h" 

extern tableau t ;

// affiche le tableau
void affiche();
