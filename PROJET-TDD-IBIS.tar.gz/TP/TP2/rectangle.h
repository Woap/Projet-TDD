#ifndef __RECTANGLE_H_
#define __RECTANGLE_H_



typedef struct { point xmin_ymin; point xmax_ymax; } rectangle;
float surface_rectangle(rectangle r);


#endif
