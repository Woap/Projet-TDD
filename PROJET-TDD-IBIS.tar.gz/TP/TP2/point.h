#ifndef __POINT_H_
#define __POINT_H_

typedef struct { float x ; float y ; } point ;


float distance(point pt1, point pt2);


#endif
