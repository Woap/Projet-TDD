#include <stdio.h>
#include <stdlib.h>
#include "point.h"
#include "rectangle.h"
#include "cercle.h"
#include <math.h>


int appartient( point pt, cercle c )
{
    if ((distance(pt, c.centre)) <= c.rayon)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

point point_aleatoire(rectangle r)
{

    float x = ( rand()/(double)RAND_MAX ) * (r.xmax_ymax.x-r.xmin_ymin.x) + r.xmin_ymin.x;
    float y = ( rand()/(double)RAND_MAX ) * (r.xmax_ymax.x-r.xmin_ymin.x) + r.xmin_ymin.x;
    point s;
    s.x = x;
    s.y = y;

    return s;

}



float distance ( point pt1 , point pt2 )
{
    float x = pt2.x - pt1.x;
    float y = pt2.y - pt1.y;
    return sqrt( pow(x, 2) + pow(y,2));
}
