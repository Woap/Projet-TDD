#ifndef __PRODUIT_H_
#define __PRODUIT_H_
#include "type.h"

float scalaire ( vecteur v1, vecteur v2 );
vecteur vectorielles ( vecteur v1, vecteur v2 );

#endif
