#ifndef __TYPE_H_
#define __TYPE_H_

typedef struct { float x ; float y ; float z ; } vecteur;

#endif



