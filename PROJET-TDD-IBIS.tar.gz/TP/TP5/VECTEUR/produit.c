#include <stdio.h>
#include <stdlib.h>
#include "produit.h"



float scalaire ( vecteur v1, vecteur v2 )
{
    float prod;
    prod = v1.x*v2.x + v1.y*v2.y + v1.z*v2.z;
    return prod;
}


vecteur vectorielles ( vecteur v1, vecteur v2 )
{
    vecteur v1v2;
    v1v2.x=v1.y*v2.z - v1.z*v2.y;
    v1v2.y=v1.z*v2.x - v1.x*v2.z;
    v1v2.z=v1.x*v2.y - v1.y*v2.x;

    return v1v2;
}
