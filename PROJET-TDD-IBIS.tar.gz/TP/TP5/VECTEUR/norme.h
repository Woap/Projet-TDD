#ifndef __NORME_H_
#define __NORME_H_
#include "type.h"

float norme ( vecteur v );

#endif
