#include <stdio.h>
#include <stdlib.h>
#include "norme.h"
#include "produit.h"
#include "type.h"

int main( int argc,char **argv)
{
    int i;
    int j;
    vecteur v1;
    vecteur v2;

    v1.x=atof(argv[1]);
    v1.y=atof(argv[2]);
    v1.z=atof(argv[3]);

    v2.x=atof(argv[4]);
    v2.y=atof(argv[5]);
    v2.z=atof(argv[6]);

    float nor1=norme(v1);
    float nor2=norme(v2);

    float scal=scalaire(v1,v2);
    vecteur prod=vectorielles(v1,v2);

    printf("Norme du vecteur 1 : %f \n Norme du vecteur 2 %f",nor1,nor2);
    printf("Produit scalaire de v1 et v2 : %f \n",scal);
    printf("Produit vectoreil de v1 et v2 : (%f,%f,%f) \n",prod.x,prod.y,prod.z);

    return 0;
}


