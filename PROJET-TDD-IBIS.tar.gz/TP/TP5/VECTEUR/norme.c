#include <stdio.h>
#include <stdlib.h>
#include "norme.h"
#include "type.h"
#include <math.h>

float norme ( vecteur v )
{
    float nor;
    nor=sqrt(pow(v.x,2) + pow(v.y,2) + pow(v.z,2));
    return nor;
}
