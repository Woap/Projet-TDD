#include <stdio.h>
#include <stdlib.h>

#define PI 3.14
#define CUBE(X) (X*X*X)
#define V_SPHERE(X) ((4*PI*X)/3)

int main (int argc, char **argv)
{
    int i;
    float c=0.0;
    float v=0.0;
    float total=0.0;
    for (i=1 ; i < argc  ; i++)
    {
        c=CUBE(atof(argv[i]));
        v= V_SPHERE(c);
        total=total + v;
    }

   printf("%f \n",total);
    return 0;
}




