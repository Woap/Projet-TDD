#ifndef STRUCT_GEO_H
#define STRUCT_GEO_H


typedef struct { float x ; float y ; } point ;
typedef struct { point xmin_ymin; point xmax_ymax; } rectangle;
typedef struct { point centre ; float rayon;  } cercle;

#endif
