#ifndef __CERCLE_H_
#define __CERCLE_H_


#include "struct.h"


float xxmin(cercle c1, cercle c2);
float yymin(cercle c1, cercle c2);
float xxmax(cercle c1, cercle c2);
float yymax(cercle c1, cercle c2);
int appartient(point pt, cercle c);

#endif
