#ifndef __POINT_H_
#define __POINT_H_


#include "struct.h"

float distance(point pt1, point pt2);





#endif
