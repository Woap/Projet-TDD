#include <stdio.h>
#include <stdlib.h>
#include "rectangle.h"
#include "cercle.h"
#include "point.h"




rectangle rectangle_encadrant( cercle c1, cercle c2)
{
    float xmi = xxmin(c1,c2);
    float ymi = yymin(c1,c2);
    float xma = xxmax(c1,c2);
    float yma = yymax(c1,c2);

    point xmin_ymin;
    point xmax_ymax;

    xmin_ymin.x=xmi;
    xmin_ymin.y=ymi;
    xmax_ymax.x=xma;
    xmax_ymax.y=yma;


    rectangle r;
    r.xmin_ymin=xmin_ymin;
    r.xmax_ymax=xmax_ymax;

    return r;
}

float surface_rectangle (rectangle r)
{
    float hauteur = distance ( r.xmin_ymin,r.xmax_ymax );
    float longueur = distance ( r.xmin_ymin,r.xmax_ymax );


    float surface = hauteur * longueur ;

    return surface;
}


point point_aleatoire(rectangle r)
{

    float x = ( rand()/(float)RAND_MAX ) * (r.xmax_ymax.x-r.xmin_ymin.x) + r.xmin_ymin.x;
    float y = ( rand()/(float)RAND_MAX ) * (r.xmax_ymax.y-r.xmin_ymin.y) + r.xmin_ymin.y;
    point s;
    s.x = x;
    s.y = y;

    return s;

}
