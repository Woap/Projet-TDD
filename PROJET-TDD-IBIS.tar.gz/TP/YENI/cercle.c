#include <stdio.h>
#include <stdlib.h>
#include "point.h"
#include "cercle.h"




float xxmin(cercle c1,cercle c2)
{
    if ( (c1.centre.x - c1.rayon) < (c2.centre.x - c2.rayon) )
    {
        return (c1.centre.x - c1.rayon);
    }
    else
    {
        return (c2.centre.x - c2.rayon);
    }
}

float yymin(cercle c1,cercle c2)
{
    if ( (c1.centre.y - c1.rayon) < (c2.centre.y - c2.rayon) )
    {
        return (c1.centre.y - c1.rayon);
    }
    else
    {
        return (c2.centre.y - c2.rayon);
    }
}

float xxmax(cercle c1,cercle c2)
{
    if ( (c1.centre.x + c1.rayon) < (c2.centre.x + c2.rayon) )
    {
        return (c2.centre.x + c2.rayon);
    }
    else
    {
        return (c1.centre.x + c1.rayon);
    }
}

float yymax(cercle c1,cercle c2)
{
    if ( (c1.centre.y + c1.rayon) < (c2.centre.y + c1.rayon ))
    {
        return (c2.centre.y + c2.rayon);
    }
    else
    {
        return (c1.centre.y + c1.rayon);
    }
}


int appartient( point pt, cercle c )
{
    if ((distance(pt, c.centre)) <= c.rayon)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

