#include <stdio.h>
#include <stdlib.h>
#include "point.h"
#include "rectangle.h"
#include "cercle.h"
#include <math.h>



float distance ( point pt1 , point pt2 )
{
    float x = pt2.x - pt1.x;
    float y = pt2.y - pt1.y;
    return (sqrt( pow(x, 2) + pow(y,2)));
}
