#ifndef __RECTANGLE_H_
#define __RECTANGLE_H_




#include "struct.h"

rectangle rectangle_encadrant( cercle c1, cercle c2);
float surface_rectangle(rectangle r);
point point_aleatoire(rectangle r);

#endif
