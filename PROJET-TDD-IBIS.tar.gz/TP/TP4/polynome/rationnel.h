#ifndef __RATIONNEL_H_
#define __RATIONNEL_H_

typedef struct { int p ; int q ; } rational;

rationnal new_rational( int p , int q );

rational add_rational(rational x, rational y);
rational mult_rational(rational x, rational y);
rational power_rational(rational x, int s);

rational int_to_rational(int s);
int rational_to_int(rational x);




#endif
