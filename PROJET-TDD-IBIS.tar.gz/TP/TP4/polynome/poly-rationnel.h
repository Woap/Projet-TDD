/**
* @file poly-rationnel.h
* @brief header contenant les fonctions pour les polynomes
* @author ibis ibrahim
* @date 30/03/2015
*/

#ifndef __POLY-RATIONNEL_H_
#define __POLY-RATIONNEL_H_

#include "rationnel.h"
#define MAX_SIZE_POLY 10



typedef struct { rational tab[MAX_SIZE_POLY]; int degre ;} Polynome;

/**
* @param Polynome x -> objet de type polynome 
* @return retourne un nouveau polynome
*/
Polynome new_polynome( Polynome x );

void set_coef_polynome( Polynome x , rational c , int d );

#endif
