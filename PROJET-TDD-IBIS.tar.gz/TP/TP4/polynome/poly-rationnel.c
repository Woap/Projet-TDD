#include <stdio.h>
#include <stdlib.h>
#include "rationnel.h"
#include "poly-rationnel.h"

Polynome new_polynome( Polynome x )
{
    int i;
    for ( i = 0 ; i < MAX_SIZE_POLY ; i ++ )
    {
        x.tab[i].p=0;
        x.tab[i].s=0;
    }

    return x;
}

void set_coef_polynome( Polynome x , rational c , int d )
{
    x.tab[d].p=c.p;
    x.tab[d].q=c.q;

}

rational get_coef_polynome( Polynome x, int d)
{
    rational r;
    r.p=x.tab[d].p;
    r.q=x.tab[d].q;

    return r;

}

int get_degree_polynome ( Polynome x )
{
    int i;
    for ( i = 0 ; i < MAX_SIZE_POLY ; i++ )
    {
        if ( x.tab[i].p != 0 )
        {
            return i;
        }
    }
}


