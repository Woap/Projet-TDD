#include <stdio.h>
#include <stdlib.h>
#include "rationnel.h"
#include <math.h>

rational new_rational ( int p , int q )
{
    rational x;
    x.p=p;
    x.q=q;

    return x;
}

rational add_rational ( rational x, rational y)
{
    rational sum;
    sum.p=(x.p)+(y.p);
    sum.q=(x.q)*(y.q);

    return sum;
}

rational mult_rational ( rational x, rational y)
{
    rational mult;
    mult.p=(x.p) * (y.p) ;
    mult.q=(x.q) * (y.q) ;

    return mult;

}

rational power_rational ( rational x, int s )
{
    rational powr;
    powr.p=pow(x.p,s);
    powr.q=pow(y.p,s);

    return powr;
}

rational int_to_rational(int s)
{
    rational enti;
    enti.p=s;
    enti.q=s;

    return rational;
}

int rational_to_int(rational x )
{
    int s;
    s=(x.p) / (x.q);

    return s;
}



