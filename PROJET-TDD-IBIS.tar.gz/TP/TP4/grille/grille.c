#include <stdio.h>
#include <stdlib.h>
#include "grille.h"

grille new_grille( int n, int m)
{
    int i;
    grille nouv;
    nouv.n=n;
    nouv.m=m;
    nouv.grille=(grille **) malloc ((n)*sizeof(grille*));
        for ( i=0 ; i < n ; i++ )
            nouv.grille[i]=(grille*) malloc ((m)*sizeof(grille));

    return nouv;

}


grille init_grille(grille x)
{
    int i,j;
    for ( i=0 ; i < (x.n) ; i++ )
        for ( j=0 ; j < (x.m) ; j++ )
            x.grille[i][j]=0;
}

void free_grille(grille x)
{
    int i;
    for ( i = 0 ; i < (x.n) ; i ++ )
    {
        free(x.grille[i]);
        x.grille[i]= NULL;
    }

    free(x.grille);
    x.grille= NULL;
}

void affiche_grille(grille x)
{
    int i,j;

    printf("\n");
    for ( i = 0 ; i < (x.n) ; i++ )
    {
        printf("|");
        for ( j = 0 ; j < (x.m) ; j++ )
        {
            printf("%d",x.grille[i][j]);

        }
        printf("|\n");
    }

}

void charger_grille(grille x,
{
    char * line[100];
    int n,m;
    FILE *fd;
    fd= fopen("grille1.txt","r");
    if ( fd == NULL )
    {
        perror("Erreur ouverture grille");
        exit 1;
    }

    fscanf(fd,"%d %d",&n,&m);

    x.n=n;
    x.m=m;





    fgets(line,100,fd); //lecture de la ligne

    fclose(fd);
}


int nb_case_nvide(grille x)
{
    int i,j;
    int nb_case=0;
    for ( i = 0 ; i < x.n ; i++)
        for ( j=0 ; j < x.m ; j++)
            if ( x.grille[i][j] != 0 )
            {
                nb_case++;
            }
    return nb_case;
}



