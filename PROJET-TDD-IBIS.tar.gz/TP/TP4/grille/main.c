#include <stdio.h>
#include <stdlib.h>
#include "grille.h"

int main()
{
    int n,m;
    printf(" N = "); scanf(" %d",&n);
    printf(" M = "); scanf(" %d",&m);
    grille s;

    s=new_grille(n,m);
    init_grille(s);
    affiche_grille(s);

    free_grille(s);

    return 0;

}

